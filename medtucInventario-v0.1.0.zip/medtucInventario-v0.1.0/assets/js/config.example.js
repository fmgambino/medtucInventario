window.MEDTUC_CONFIG = {
  SUPABASE_URL: 'https://TU-PROYECTO.supabase.co',
  SUPABASE_ANON_KEY: 'TU_ANON_KEY',
  PROJECT_URL: 'https://fmgambino.github.io/medtucInventario/'
};
