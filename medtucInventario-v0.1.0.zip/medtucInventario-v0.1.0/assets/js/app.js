(() => {
  const C = window.MEDTUC_CONFIG || {};
  const configured = C.SUPABASE_URL && !C.SUPABASE_URL.includes('TU-PROYECTO') && C.SUPABASE_ANON_KEY && !C.SUPABASE_ANON_KEY.includes('TU_ANON_KEY');
  const sb = configured ? window.supabase.createClient(C.SUPABASE_URL, C.SUPABASE_ANON_KEY) : null;
  const $ = s => document.querySelector(s);
  const state = { page: 0, size: 10, filter: '', rows: [], total: 0, user: null, poll: null };

  const toast = (icon, title, text='') => Swal.fire({icon,title,text,confirmButtonText:'Aceptar',background:'#101827',color:'#edf4ff'});
  const setBadge = () => {
    const el = $('#connectionBadge');
    if (configured) { el.textContent='● Supabase configurado'; el.style.color='#69d6a5'; }
    else { el.textContent='● Demo · falta configurar Supabase'; el.style.color='#ffd27d'; }
  };

  function safeName(v){ return String(v||'').trim().replace(/[<>]/g,'').slice(0,80); }
  async function loadCatalogs(){
    if(!sb) return;
    const [{data:offices},{data:equipment}] = await Promise.all([
      sb.from('offices').select('id,name').order('name'),
      sb.from('equipment_names').select('id,name,office_id').order('name')
    ]);
    const o=$('#officeSelect'); o.innerHTML='<option value="">Seleccionar…</option>'+(offices||[]).map(x=>`<option value="${x.id}">${x.name}</option>`).join('');
    o.dataset.items=JSON.stringify(offices||[]);
    const e=$('#equipmentSelect'); e.dataset.items=JSON.stringify(equipment||[]); renderEquipment();
  }
  function renderEquipment(){
    const oid=$('#officeSelect').value;
    let items=[]; try{items=JSON.parse($('#equipmentSelect').dataset.items||'[]')}catch{}
    items=items.filter(x=>!oid || x.office_id===oid);
    $('#equipmentSelect').innerHTML='<option value="">Seleccionar…</option>'+items.map(x=>`<option value="${x.id}">${x.name}</option>`).join('');
  }
  async function createCatalog(type){
    if(!sb) return toast('info','Modo demo','Configurá Supabase para crear registros reales.');
    const officeId=$('#officeSelect').value;
    if(type==='equipment' && !officeId) return toast('warning','Primero seleccioná una oficina');
    const {value:name}=await Swal.fire({title:type==='office'?'Nueva oficina':'Nuevo equipo',input:'text',inputLabel:type==='office'?'Nombre de la oficina':'Nombre del equipo',showCancelButton:true,confirmButtonText:'Crear',cancelButtonText:'Cancelar',background:'#101827',color:'#edf4ff',inputValidator:v=>!safeName(v)?'Ingresá un nombre válido':undefined});
    if(!name) return;
    const payload=type==='office'?{name:safeName(name)}:{name:safeName(name),office_id:officeId};
    const table=type==='office'?'offices':'equipment_names';
    const {error}=await sb.from(table).insert(payload);
    if(error) return toast('error','No se pudo crear',error.message);
    await loadCatalogs(); toast('success','Creado correctamente','Por seguridad, este dato solo podrá administrarse desde el área autorizada.');
  }

  function psEscape(s){ return String(s).replace(/'/g,"''"); }
  function buildCollector(officeId,equipmentId,officeName,equipmentName){
    return `# MEDTUC Inventario v0.1.0\n# Recopilador generado para ${equipmentName}\n$ErrorActionPreference = 'Stop'\n$SupabaseUrl = '${psEscape(C.SUPABASE_URL)}'\n$AnonKey = '${psEscape(C.SUPABASE_ANON_KEY)}'\n$OfficeId = '${psEscape(officeId)}'\n$EquipmentId = '${psEscape(equipmentId)}'\n$OfficeName = '${psEscape(officeName)}'\n$EquipmentName = '${psEscape(equipmentName)}'\n\ntry {\n  Write-Host 'MEDTUC Inventario - recopilando datos...' -ForegroundColor Cyan\n  $cs = Get-CimInstance Win32_ComputerSystem\n  $cpu = Get-CimInstance Win32_Processor | Select-Object -First 1\n  $os = Get-CimInstance Win32_OperatingSystem\n  $board = Get-CimInstance Win32_BaseBoard | Select-Object -First 1\n  $gpu = Get-CimInstance Win32_VideoController | Select-Object -First 1\n  $disks = Get-CimInstance Win32_DiskDrive | Where-Object {$_.Size -gt 0}\n  $ramModules = Get-CimInstance Win32_PhysicalMemory\n  $ramGB = [math]::Round(($ramModules | Measure-Object Capacity -Sum).Sum / 1GB,0)\n  $memMap = @{20='DDR';21='DDR2';24='DDR3';26='DDR4';34='DDR5'}\n  $ramType = ($ramModules | ForEach-Object { if($memMap.ContainsKey([int]$_.SMBIOSMemoryType)){$memMap[[int]$_.SMBIOSMemoryType]} else {'No detectado'} } | Select-Object -Unique) -join ', '\n  $storage = ($disks | ForEach-Object { $gb=[math]::Round($_.Size/1GB,0); $kind=if($_.MediaType -match 'SSD'){'SSD'}elseif($_.Model -match 'SSD'){'SSD'}else{'HDD'}; \"$gb GB ($kind)\" }) -join ' + '\n  $arch = if($os.OSArchitecture){$os.OSArchitecture}else{'No detectado'}\n  $payload = @{\n    office_id=$OfficeId; equipment_id=$EquipmentId; office_name=$OfficeName; equipment_name=$EquipmentName;\n    brand=if($cs.Manufacturer){$cs.Manufacturer}else{'No detectado'};\n    processor=$cpu.Name; cores=[int]$cpu.NumberOfCores; operating_system=\"$($os.Caption) ($arch)\";\n    motherboard=(\"$($board.Manufacturer) $($board.Product)\").Trim(); ram_gb=[int]$ramGB; ram_type=$ramType;\n    storage=$storage; graphics=$gpu.Name; hostname=$env:COMPUTERNAME; collector_version='0.1.0'\n  } | ConvertTo-Json -Depth 4\n  $headers = @{ apikey=$AnonKey; Authorization=\"Bearer $AnonKey\"; Prefer='return=representation'; 'Content-Type'='application/json' }\n  $uri = \"$SupabaseUrl/rest/v1/inventories\"\n  $r = Invoke-RestMethod -Method Post -Uri $uri -Headers $headers -Body $payload\n  Write-Host 'OK - inventario guardado correctamente.' -ForegroundColor Green\n  Start-Sleep -Seconds 2\n} catch {\n  Write-Host ('ERROR: ' + $_.Exception.Message) -ForegroundColor Red\n  Read-Host 'Presione ENTER para cerrar'\n  exit 1\n}\n`;
  }

  async function generateCollector(){
    const officeId=$('#officeSelect').value, equipmentId=$('#equipmentSelect').value;
    if(!officeId || !equipmentId) return toast('warning','Faltan datos','Seleccioná la oficina y el nombre del equipo.');
    if(!sb) return toast('info','Primero configurá Supabase','Abrí assets/js/config.example.js y completá URL + anon key.');
    const officeName=$('#officeSelect').selectedOptions[0].textContent;
    const equipmentName=$('#equipmentSelect').selectedOptions[0].textContent;
    const ps=buildCollector(officeId,equipmentId,officeName,equipmentName);
    const blob=new Blob([ps],{type:'text/plain;charset=utf-8'}); const url=URL.createObjectURL(blob);
    const a=document.createElement('a'); a.href=url; a.download=`MEDTUC_${equipmentName.replace(/[^a-z0-9_-]/gi,'_')}.ps1`; a.click(); URL.revokeObjectURL(url);
    $('#syncPanel').classList.remove('hidden');
    $('#syncText').textContent=`Ejecutá MEDTUC_${equipmentName}.ps1. Verificaremos el registro automáticamente.`;
    startPolling(equipmentId);
    Swal.fire({icon:'info',title:'Recopilador descargado',html:'Abrí el archivo descargado con <b>PowerShell</b>. Si Windows lo bloquea, usá clic derecho → Ejecutar con PowerShell.',confirmButtonText:'Entendido',background:'#101827',color:'#edf4ff'});
  }
  function startPolling(equipmentId){
    clearInterval(state.poll); let tries=0; const started=new Date(Date.now()-60000).toISOString();
    state.poll=setInterval(async()=>{ tries++; const {data}=await sb.from('inventories').select('id,created_at,equipment_name').eq('equipment_id',equipmentId).gte('created_at',started).order('created_at',{ascending:false}).limit(1); if(data?.length){clearInterval(state.poll); $('#syncPanel').classList.add('hidden'); toast('success','Equipo registrado',`${data[0].equipment_name} fue guardado correctamente en el inventario central.`);} if(tries>60){clearInterval(state.poll); $('#syncText').textContent='No detectamos el registro todavía. Podés volver a ejecutar el recopilador.';} },3000);
  }

  async function login(){ if(!sb)return toast('info','Supabase no configurado'); const email=$('#adminEmail').value.trim(), password=$('#adminPassword').value; const {data,error}=await sb.auth.signInWithPassword({email,password}); if(error)return toast('error','Acceso rechazado',error.message); state.user=data.user; await showDashboard(); }
  async function showDashboard(){
    const {data:role,error}=await sb.from('admin_users').select('user_id').eq('user_id',state.user.id).maybeSingle();
    if(error || !role){ await sb.auth.signOut(); state.user=null; return toast('error','Sin permisos','La cuenta no está habilitada como administrador.'); }
    $('#loginCard').classList.add('hidden'); $('#dashboard').classList.remove('hidden'); $('#btnLogout').classList.remove('hidden'); await refreshStats(); await loadInventory();
  }
  async function refreshStats(){
    const [{count:total},{count:offices},{data:last}] = await Promise.all([
      sb.from('inventories').select('*',{count:'exact',head:true}), sb.from('offices').select('*',{count:'exact',head:true}), sb.from('inventories').select('created_at').order('created_at',{ascending:false}).limit(1)
    ]); $('#statTotal').textContent=total||0; $('#statOffices').textContent=offices||0; $('#statLast').textContent=last?.[0]?new Date(last[0].created_at).toLocaleString('es-AR'):'—';
  }
  async function loadInventory(){
    const from=state.page*state.size,to=from+state.size-1; let q=sb.from('inventories').select('*',{count:'exact'}).order('created_at',{ascending:false}).range(from,to);
    if(state.filter){ const f=state.filter.replace(/[,%()]/g,' '); q=q.or(`office_name.ilike.%${f}%,equipment_name.ilike.%${f}%,brand.ilike.%${f}%,processor.ilike.%${f}%,operating_system.ilike.%${f}%`); }
    const {data,error,count}=await q; if(error)return toast('error','Error al consultar',error.message); state.rows=data||[]; state.total=count||0;
    $('#inventoryBody').innerHTML=state.rows.map(r=>`<tr><td>${new Date(r.created_at).toLocaleString('es-AR')}</td><td>${r.office_name||''}</td><td>${r.brand||''}</td><td>${r.equipment_name||''}</td><td>${r.processor||''}</td><td>${r.cores??''}</td><td>${r.operating_system||''}</td><td>${r.motherboard||''}</td><td>${r.ram_gb??''} GB</td><td>${r.ram_type||''}</td><td>${r.storage||''}</td><td>${r.graphics||''}</td></tr>`).join('') || '<tr><td colspan="12">Sin resultados</td></tr>';
    const pages=Math.max(1,Math.ceil(state.total/state.size)); $('#pageInfo').textContent=`${state.total} registros · Página ${state.page+1} de ${pages}`; $('#prevPage').disabled=state.page===0; $('#nextPage').disabled=state.page+1>=pages;
  }
  async function fetchAllFiltered(){ let q=sb.from('inventories').select('*').order('created_at',{ascending:false}); if(state.filter){const f=state.filter.replace(/[,%()]/g,' ');q=q.or(`office_name.ilike.%${f}%,equipment_name.ilike.%${f}%,brand.ilike.%${f}%,processor.ilike.%${f}%,operating_system.ilike.%${f}%`)} const {data,error}=await q.limit(10000); if(error)throw error; return data||[]; }
  const csvCell=v=>'"'+String(v??'').replace(/"/g,'""')+'"';
  async function exportCSV(){ const rows=await fetchAllFiltered(); const headers=['Fecha','Oficina','Marca','NombreEquipo','Procesador','Nucleos','SistemaOperativo','PlacaMadre','RAM_GB','RAM_Tipo','Almacenamiento','TarjetaGrafica']; const lines=[headers.map(csvCell).join(';'),...rows.map(r=>[new Date(r.created_at).toLocaleString('es-AR'),r.office_name,r.brand,r.equipment_name,r.processor,r.cores,r.operating_system,r.motherboard,r.ram_gb,r.ram_type,r.storage,r.graphics].map(csvCell).join(';'))]; downloadText('\ufeff'+lines.join('\n'),`MEDTUC_Inventario_${stamp()}.csv`,'text/csv;charset=utf-8'); }
  async function exportPDF(){ const rows=await fetchAllFiltered(); const {jsPDF}=window.jspdf; const doc=new jsPDF({orientation:'landscape',unit:'mm',format:'a4'}); doc.setFontSize(16); doc.text('MEDTUC Inventario de Equipos',14,14); doc.setFontSize(8); doc.text(`Exportado: ${new Date().toLocaleString('es-AR')}  |  Usuario: ${state.user?.email||'Administrador'}`,14,20); doc.autoTable({startY:25,styles:{fontSize:5.5,cellPadding:1.4},head:[['Fecha','Oficina','Marca','Equipo','Procesador','Núcleos','SO','Placa madre','RAM','Tipo','Almacenamiento','Gráfica']],body:rows.map(r=>[new Date(r.created_at).toLocaleString('es-AR'),r.office_name,r.brand,r.equipment_name,r.processor,r.cores,r.operating_system,r.motherboard,`${r.ram_gb||''} GB`,r.ram_type,r.storage,r.graphics])}); doc.save(`MEDTUC_Inventario_${stamp()}.pdf`); }
  function stamp(){ const d=new Date(); return `${d.getFullYear()}${String(d.getMonth()+1).padStart(2,'0')}${String(d.getDate()).padStart(2,'0')}_${String(d.getHours()).padStart(2,'0')}${String(d.getMinutes()).padStart(2,'0')}`; }
  function downloadText(text,name,type){const b=new Blob([text],{type});const u=URL.createObjectURL(b);const a=document.createElement('a');a.href=u;a.download=name;a.click();URL.revokeObjectURL(u);}

  $('#officeSelect').addEventListener('change',renderEquipment); $('#addOffice').onclick=()=>createCatalog('office'); $('#addEquipment').onclick=()=>createCatalog('equipment'); $('#generateCollector').onclick=generateCollector;
  $('#btnAdmin').onclick=()=>{$('#userView').classList.remove('active');$('#adminView').classList.add('active')}; $('#btnBack').onclick=()=>{$('#adminView').classList.remove('active');$('#userView').classList.add('active')}; $('#loginBtn').onclick=login;
  $('#btnLogout').onclick=async()=>{await sb.auth.signOut();location.reload()}; $('#pageSize').onchange=e=>{state.size=+e.target.value;state.page=0;loadInventory()};
  let filterTimer; $('#filterInput').oninput=e=>{clearTimeout(filterTimer);filterTimer=setTimeout(()=>{state.filter=e.target.value.trim();state.page=0;loadInventory()},300)};
  $('#prevPage').onclick=()=>{if(state.page>0){state.page--;loadInventory()}}; $('#nextPage').onclick=()=>{state.page++;loadInventory()}; $('#exportCsv').onclick=exportCSV; $('#exportPdf').onclick=exportPDF;
  setBadge(); loadCatalogs(); if(sb){sb.auth.getSession().then(({data})=>{if(data.session){state.user=data.session.user;}})}
})();
