-- MEDTUC Inventario v0.1.0
create extension if not exists pgcrypto;

create table if not exists public.offices (
  id uuid primary key default gen_random_uuid(),
  name text not null unique check (char_length(name) between 2 and 80),
  created_at timestamptz not null default now()
);

create table if not exists public.equipment_names (
  id uuid primary key default gen_random_uuid(),
  office_id uuid not null references public.offices(id),
  name text not null check (char_length(name) between 1 and 80),
  created_at timestamptz not null default now(),
  unique(office_id,name)
);

create table if not exists public.inventories (
  id uuid primary key default gen_random_uuid(),
  office_id uuid references public.offices(id),
  equipment_id uuid references public.equipment_names(id),
  office_name text not null,
  equipment_name text not null,
  brand text,
  processor text,
  cores integer,
  operating_system text,
  motherboard text,
  ram_gb integer,
  ram_type text,
  storage text,
  graphics text,
  hostname text,
  collector_version text,
  created_at timestamptz not null default now()
);

create table if not exists public.admin_users (
  user_id uuid primary key references auth.users(id) on delete cascade,
  created_at timestamptz not null default now()
);

alter table public.offices enable row level security;
alter table public.equipment_names enable row level security;
alter table public.inventories enable row level security;
alter table public.admin_users enable row level security;

-- Usuarios públicos: solo pueden consultar catálogo y crear. Nunca editar/borrar.
create policy "public_read_offices" on public.offices for select to anon, authenticated using (true);
create policy "public_insert_offices" on public.offices for insert to anon, authenticated with check (true);
create policy "public_read_equipment" on public.equipment_names for select to anon, authenticated using (true);
create policy "public_insert_equipment" on public.equipment_names for insert to anon, authenticated with check (true);
create policy "public_insert_inventory" on public.inventories for insert to anon, authenticated with check (true);

-- El público solo puede comprobar el impacto de un registro reciente. MVP: lectura permitida.
-- Para producción se recomienda reemplazar esta policy por una Edge Function/RPC con token de sesión.
create policy "public_read_inventory_mvp" on public.inventories for select to anon using (true);

-- Administradores autenticados habilitados en admin_users.
create policy "admin_read_admin_users" on public.admin_users for select to authenticated using (auth.uid() = user_id);
create policy "admin_read_inventory" on public.inventories for select to authenticated using (exists(select 1 from public.admin_users a where a.user_id=auth.uid()));

-- IMPORTANTE: no se crean policies UPDATE ni DELETE para offices/equipment/inventories.
-- Por lo tanto el frontend público y admin no puede editar ni borrar registros.
