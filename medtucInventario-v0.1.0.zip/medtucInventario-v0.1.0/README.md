# MEDTUC Inventario v0.1.0

Primera versión funcional para publicar en GitHub Pages y centralizar inventario de PCs Windows en Supabase.

## Incluye
- Portal responsive HTML5 + CSS3 + JavaScript.
- UI minimalista con blur/glass.
- SweetAlert2.
- Alta de oficinas y nombres de equipo sin edición ni borrado desde el portal.
- Generador de recopilador PowerShell personalizado.
- Detección de marca, CPU, núcleos, Windows, placa madre, RAM, tipo RAM, almacenamiento, GPU y hostname.
- Confirmación automática de impacto en Supabase.
- Login de administrador con Supabase Auth.
- Tabla con 5/10/25/50/100/500/1000 registros.
- Paginación anterior/siguiente.
- Filtro remoto con debounce (consulta Supabase, estilo AJAX).
- Exportación CSV y PDF con título, fecha/hora y usuario administrador.
- Datos CSV originales incluidos en /data.

## Puesta en marcha
1. Crear un proyecto en Supabase.
2. Ejecutar `supabase/schema.sql` desde SQL Editor.
3. Opcional: ejecutar `supabase/seed.sql`.
4. Crear un usuario administrador desde Supabase Authentication > Users.
5. Copiar el UUID del usuario y ejecutar:
   `insert into public.admin_users(user_id) values ('UUID-DEL-USUARIO');`
6. Editar `assets/js/config.example.js` con SUPABASE_URL y SUPABASE_ANON_KEY.
7. Subir el contenido del proyecto al repositorio GitHub `fmgambino/medtucInventario`.
8. Activar GitHub Pages desde la rama principal.

## Nota de seguridad para producción
Esta v0.1.0 es un MVP funcional. La policy `public_read_inventory_mvp` permite lectura anónima para que la web confirme el impacto del recopilador. Para producción, se recomienda eliminar esa policy y mover la confirmación/ingesta a una Supabase Edge Function o RPC protegida mediante token de registro de un solo uso.

## PowerShell
Windows puede advertir al ejecutar scripts `.ps1` descargados. Para una distribución institucional sin fricción, la siguiente versión debería empaquetar el recopilador como `.exe` firmado digitalmente o instalar un agente firmado.
