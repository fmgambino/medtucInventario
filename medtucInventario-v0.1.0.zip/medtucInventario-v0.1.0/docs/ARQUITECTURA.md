# Arquitectura

Usuario -> GitHub Pages -> selecciona/crea Oficina + Equipo -> genera PS1 personalizado -> Windows/CIM -> Supabase REST -> PostgreSQL -> portal detecta registro -> SweetAlert OK.

Administrador -> Supabase Auth -> RLS admin_users -> consulta paginada/filtrada -> exporta CSV/PDF.
