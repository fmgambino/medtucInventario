import { createClient } from 'npm:@supabase/supabase-js@2.57.4'
import JSZip from 'npm:jszip@3.10.1'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
  'Access-Control-Max-Age': '86400',
}
const json = (body: unknown, status = 200) => new Response(JSON.stringify(body), {
  status,
  headers: { ...corsHeaders, 'Content-Type': 'application/json; charset=utf-8' },
})
const bytesFromBase64 = (s: string) => Uint8Array.from(atob(s), c => c.charCodeAt(0))
const base64FromBytes = (bytes: Uint8Array) => {
  let out = ''
  const size = 0x8000
  for (let i = 0; i < bytes.length; i += size) out += String.fromCharCode(...bytes.subarray(i, i + size))
  return btoa(out)
}
const sha256 = async (text: string) => {
  const digest = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(text))
  return [...new Uint8Array(digest)].map(x => x.toString(16).padStart(2,'0')).join('')
}

async function githubPut(path: string, bytes: Uint8Array, token: string, owner: string, repo: string, branch: string, message: string) {
  const url = `https://api.github.com/repos/${owner}/${repo}/contents/${encodeURI(path)}`
  const headers = {
    Authorization: `Bearer ${token}`,
    Accept: 'application/vnd.github+json',
    'X-GitHub-Api-Version': '2022-11-28',
    'Content-Type': 'application/json',
  }
  let currentSha: string | undefined
  const current = await fetch(`${url}?ref=${encodeURIComponent(branch)}`, { headers })
  if (current.ok) currentSha = (await current.json()).sha
  else if (current.status !== 404) throw new Error(`GitHub GET ${path}: ${current.status} ${await current.text()}`)

  const payload: Record<string, unknown> = {
    message,
    content: base64FromBytes(bytes),
    branch,
  }
  if (currentSha) payload.sha = currentSha
  const put = await fetch(url, { method: 'PUT', headers, body: JSON.stringify(payload) })
  if (!put.ok) throw new Error(`GitHub PUT ${path}: ${put.status} ${await put.text()}`)
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response(null, { status: 204, headers: corsHeaders })
  if (req.method !== 'POST') return json({ error: 'Método no permitido' }, 405)

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!
    const anonKey = Deno.env.get('SUPABASE_ANON_KEY')!
    const serviceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
    const githubToken = Deno.env.get('GITHUB_TOKEN') || ''
    const owner = Deno.env.get('GITHUB_OWNER') || 'fmgambino'
    const repo = Deno.env.get('GITHUB_REPO') || 'medtucInventario'
    const branch = Deno.env.get('GITHUB_BRANCH') || 'dev'

    const authHeader = req.headers.get('Authorization') || ''
    const accessToken = authHeader.replace(/^Bearer\s+/i, '')
    if (!accessToken) return json({ error: 'Sesión requerida' }, 401)

    const userClient = createClient(supabaseUrl, anonKey, {
      global: { headers: { Authorization: `Bearer ${accessToken}` } },
      auth: { persistSession: false, autoRefreshToken: false },
    })
    const adminClient = createClient(supabaseUrl, serviceKey, { auth: { persistSession: false, autoRefreshToken: false } })

    const { data: userData, error: userError } = await userClient.auth.getUser(accessToken)
    if (userError || !userData.user) return json({ error: 'Sesión inválida o expirada' }, 401)
    const user = userData.user

    const { data: roleRow, error: roleError } = await adminClient.from('admin_users').select('role').eq('user_id', user.id).maybeSingle()
    if (roleError) return json({ error: roleError.message }, 500)
    if (roleRow?.role !== 'superadmin') return json({ error: 'Solo SuperAdmin puede instalar actualizaciones' }, 403)

    let body: any = {}
    try { body = await req.json() } catch { return json({ error: 'JSON inválido' }, 400) }

    if (body.action === 'health') {
      return json({ ok: true, updater: 'medtuc-updater', sql_engine: true, github_branch: branch })
    }
    if (body.action !== 'apply_zip') return json({ error: 'Acción no soportada' }, 400)
    if (!githubToken) return json({ error: 'Falta configurar GITHUB_TOKEN en los Secrets de la Edge Function' }, 500)
    if (!body.zip_base64) return json({ error: 'ZIP vacío' }, 400)

    const zip = await JSZip.loadAsync(bytesFromBase64(body.zip_base64))
    const manifestEntry = zip.file('patch.json')
    if (!manifestEntry) return json({ error: 'El patch no contiene patch.json' }, 400)
    const patch = JSON.parse(await manifestEntry.async('string'))
    const fromVersions = Array.isArray(patch.from) ? patch.from.map(String) : [String(patch.from || '')]
    const toVersion = String(patch.to || body.to_version || '').trim()
    const fromVersion = String(body.from_version || '').trim()
    if (!toVersion) return json({ error: 'patch.json no define versión destino' }, 400)
    if (fromVersion && fromVersions[0] && !fromVersions.includes(fromVersion)) {
      return json({ error: `Patch incompatible. Instalado: ${fromVersion}; permitido: ${fromVersions.join(', ')}` }, 409)
    }

    const migrationResults: any[] = []
    for (const migrationPath of (patch.migrations || [])) {
      const entry = zip.file(String(migrationPath))
      if (!entry) return json({ error: `Falta migración ${migrationPath}` }, 400)
      const sql = await entry.async('string')
      const checksum = await sha256(sql)
      const patchId = `${toVersion}:${migrationPath}:${checksum.slice(0,16)}`
      const { data, error } = await adminClient.rpc('execute_patch_migration', {
        p_patch_id: patchId,
        p_sql: sql,
        p_checksum: checksum,
      })
      if (error) return json({ error: `SQL ${migrationPath}: ${error.message}` }, 500)
      migrationResults.push({ path: migrationPath, result: data })
    }

    const files = Array.isArray(patch.files) ? patch.files.map(String) : []
    if (!files.length) return json({ error: 'patch.json no contiene files' }, 400)
    const updatedFiles: string[] = []
    for (const path of files) {
      if (!path || path.includes('..') || path.startsWith('/') || path.startsWith('supabase/')) {
        return json({ error: `Ruta no permitida: ${path}` }, 400)
      }
      const entry = zip.file(path)
      if (!entry) return json({ error: `Falta archivo ${path}` }, 400)
      const bytes = await entry.async('uint8array')
      await githubPut(path, bytes, githubToken, owner, repo, branch, `RELEVAMIENTO MANAGER v${toVersion}: ${path}`)
      updatedFiles.push(path)
    }

    await adminClient.from('update_history').insert({
      from_version: fromVersion || fromVersions[0] || '',
      to_version: toVersion,
      status: 'success',
      applied_by: user.id,
      applied_by_email: user.email,
      details: { file_name: body.file_name || null, migrations: migrationResults, files: updatedFiles, branch },
    })

    return json({ ok: true, to_version: toVersion, migrations: migrationResults, files: updatedFiles, branch })
  } catch (e) {
    return json({ error: e instanceof Error ? e.message : String(e) }, 500)
  }
})
