-- Migración v0.3.6. En instalaciones con motor updater inicializado, este archivo se ejecuta automáticamente.
-- Idempotente.
create table if not exists public.patch_migration_history (
  id uuid primary key default gen_random_uuid(),
  patch_id text not null unique,
  checksum text,
  executed_at timestamptz not null default now()
);
notify pgrst, 'reload schema';
