window.MEDTUC_CONFIG = {
  SUPABASE_URL: 'https://hmpcfqxcadxcwjgvtqog.supabase.co',
  SUPABASE_ANON_KEY: 'xxxxxxJ',
  PROJECT_URL: 'https://fmgambino.github.io/medtucInventario/'
};
